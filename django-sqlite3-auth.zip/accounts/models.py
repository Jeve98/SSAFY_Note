from django.db import models
from django.contrib.auth.models import AbstractUser

# Create your models here.
class User(AbstractUser):
    handle = models.CharField(max_length=150, unique=True, null=True, blank=True)
    profile_image_url = models.URLField(null=True, blank=True)
    roles = models.TextField(null=True, blank=True)
    email = models.EmailField(unique=True, null=True, blank=True)

    def __str__(self):
        return self.username or self.email or str(self.pk)


class UserProvider(models.Model):
    PROVIDER_CHOICES=(
        ('google', 'Google'),
    )

    provider = models.CharField(max_length=32, choices=PROVIDER_CHOICES)
    provider_user_id = models.CharField(max_length=255)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="providers")
    email_at_signup = models.EmailField(null=True, blank=True)
    access_token_enc = models.TextField(null=True, blank=True)
    refresh_token_enc = models.TextField(null=True, blank=True)
    expires_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = (('provider', 'provider_user_id'))

