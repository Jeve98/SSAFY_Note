import secrets
from django.conf import settings
from django.contrib.auth import get_user_model, login
from django.contrib.auth.decorators import login_required
from django.http import HttpRequest, HttpResponse, HttpResponseBadRequest, HttpResponseRedirect
from django.shortcuts import render, redirect
from django.views.decorators.http import require_GET
from .models import UserProvider
from .oauth import gen_pkce, build_auth_url, exchange_code_for_token, OIDCIdToken

User = get_user_model()

@require_GET
def index(request: HttpRequest) -> HttpResponse:
    return render(request, 'accounts/index.html')

@require_GET
def google_start(request: HttpRequest) -> HttpResponseRedirect | HttpResponse:
    # 0) state, PKCE 준비 -> 세션에 저장
    state = secrets.token_urlsafe(16)
    code_verifier, code_challenge = gen_pkce()
    request.session['oauth_state'] = state
    request.session['oauth_code_verifier'] = code_verifier

    # 1) Google로 리다이렉트
    url = build_auth_url(state, code_challenge)
    print(url)
    return redirect(url)

@require_GET
def google_callback(request: HttpRequest) -> HttpResponse:
    # 2) 콜백 파라미터 검증
    code = request.GET.get('code')
    state = request.GET.get('state')
    if not code or not state:
        return HttpResponseBadRequest('Missing code/state')

    if state != request.session.get('oauth_state'):
        return HttpResponseBadRequest('Invalid state')

    code_verifier = request.session.get('oauth_code_verifier')
    if not code_verifier:
        return HttpResponseBadRequest('PKCE missing')

    # 일회성 사용 후 제거
    for k in ('oauth_state', 'oauth_code_verifier'):
        if k in request.session:
            del request.session[k]

    try:
        # 3) 토큰 교환
        token = exchange_code_for_token(code, code_verifier)
        id_token = token.get('id_token')
        if not id_token:
            return HttpResponseBadRequest('No id_token')

        oidc = OIDCIdToken.from_jwt(id_token)
        oidc.basic_validate()  # iss/aud/exp 확인

        email = oidc.email or ''
        name = oidc.name or ''
        picture = oidc.picture or ''
        sub = oidc.sub

        # 4) 사용자 upsert (email 기준)
        user, created = User.objects.get_or_create(email=email, defaults={
            'username': email or sub,  # username 필수
            'first_name': name[:150] if name else '',
        })
        # name & avatar 갱신
        if name and user.first_name != name:
            user.first_name = name
        if picture and getattr(user, 'profile_image_url', None) != picture:
            user.profile_image_url = picture
        user.save()

        # 5) provider upsert
        UserProvider.objects.update_or_create(
            provider='google', provider_user_id=sub,
            defaults={'user': user, 'email_at_signup': email}
        )

        # 6) 로그인 & /me로 이동
        login(request, user)
        return redirect('me')

    except Exception as e:
        return HttpResponse(f"Internal Server Error: {e}", status=500)

@login_required
def me(request: HttpRequest) -> HttpResponse:
    return render(request, 'accounts/me.html', {'u': request.user})