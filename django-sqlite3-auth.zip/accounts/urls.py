from django.urls import path
from . import views


urlpatterns = [
    path('', views.index, name='index'),
    path('me', views.me, name='me'),
    path('api/auth/google', views.google_start, name='google_start'),
    path('api/auth/google/callback', views.google_callback, name='google_callback'),
]